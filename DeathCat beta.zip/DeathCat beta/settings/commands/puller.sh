# geolocate victim IP
echo "┌─ (DeathCat) IP"
read -p "└──# " ip 
curl "ipinfo.io/$ip?token=8bc39dad911e6b"
