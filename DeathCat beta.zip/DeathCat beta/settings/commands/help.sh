# Get commands list.
#!/bin/bash

cd settings/commands || exit

for file in *; do
  if [ -f "$file" ]; then
    echo -e "\e[31m- ${file%%.*}\e[0m - $(head -n 1 "$file")"
  fi
done
