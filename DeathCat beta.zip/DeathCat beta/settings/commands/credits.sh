# Tool and firmware developer.
echo "made with by Abrissy :3"
echo "t.me/dream_c2 - Best botnet"
echo "t.me/abrissy  - Contact Abrissy"