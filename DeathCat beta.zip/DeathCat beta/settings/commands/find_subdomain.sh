# Search subdomains for domain
#!/bin/bash

if ! command -v dig &> /dev/null; then
  echo "dnsutils package not found! install requirements"
  exit 1
fi

echo "┌─ (DeathCat) Domain"
read -p "└──# " domain

subdomains=(
  "www"
  "mail"
  "ftp"
  "test"
  "dev"
  "beta"
  "api"
  "admin"
  "portal"
  "cpanel"
  "webmail"
  "forum"
  "shop"
  "blog"
  "cdn"
  "vpn"
  "support"
  "docs"
  "tree"
  "status"
  "staging"
  "help"
  "dashboard"
  "files"
  "download"
  "m"
  "images"
  "news"
  "static"
  "video"
  "secure"
  "login"
  "user"
  "search"
  "analytics"
  "payments"
  "proxy"
  "smtp"
  "imap"
  "pop"
  "ns1"
  "ns2"
  "dns"
  "docker"
  "git"
  "db"
  "mysql"
  "backup"
  "sandbox"
  "jira"
  "jenkins"
  "grafana"
  "kibana"
  "log"
  "chat"
  "cloud"
  "media"
  "ads"
  "billing"
  "crm"
  "erp"
  "notifications"
  "office"
  "portal"
  "upload"
  "video"
  "water"
  "wiki"
)

check_subdomain() {
  subdomain=$1
  full_domain="$subdomain.$domain"
  
  if dig +short "$full_domain" | grep -q "\."; then
    echo -e "\033[31m[+]\033[0m Subdomain found! : $full_domain"
  fi
}

for subdomain in "${subdomains[@]}"; do
  check_subdomain "$subdomain"
done
