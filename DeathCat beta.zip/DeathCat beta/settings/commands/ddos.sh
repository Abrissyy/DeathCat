# DDoS attack (200-400 GBPS)
echo "┌─ (DeathCat) Username"
read -p "└──# " username
ssh $username@dreamproxy.xyz -p 1337