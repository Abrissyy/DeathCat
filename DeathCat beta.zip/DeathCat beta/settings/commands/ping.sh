# Just ip pinger.
echo "┌─ (DeathCat) IP"
read -p "└──# " ip 
ping $ip