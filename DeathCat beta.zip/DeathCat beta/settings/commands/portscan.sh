# Scan IP/domain for open ports.
#!/bin/bash
echo "┌─ (DeathCat) IP"
read -p "└──# " ip 
nmap $ip