# Install requirements.
#!/bin/bash

while true; do
    clear
    echo "choose your OS"
    echo "1 - Ubuntu/Debian/Kali"
    echo "2 - Arch"
    echo "3 - Fedora"
    echo ""
    echo "4 - Exit"
echo "┌─ (DeathCat) OS"
read -p "└──# " choice

    case $choice in
        1)
            echo "You selected Ubuntu/Debian/Kali."
            echo "installing requirements"
            sudo apt update
            sudo apt upgrade
            sudo apt install nmap
            sudo apt install git 
            sudo apt install python3
            sudo apt install python3-flask 
            sudo apt install wireshark
            sudo apt install dnsutils
            ;;
        2)
            echo "You selected Arch."
            echo "installing requirements"
            sudo pacman -Syy
            sudo pacman -Sy
            sudo pacman -S dnsutils
            sudo pacman -S nmap
            sudo pacman -S git
            sudo pacman -S python3
            sudo pacman -S python3-flask
            sudo pacman -S wireshark
            ;;
        3)
            echo "You selected Fedora."
            echo "installing requirements"
            sudo dnf upgrade
            sudo dnf install dnsutils
            sudo dnf install nmap
            sudo dnf install git
            sudo dnf install python3
            sudo dnf install python3-flask
            sudo dnf install wireshark
            ;;
        4)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo "Invalid option. Please select a number between 1 and 4."
            ;;
    esac
    read -p "Press [Enter] to continue..."
done
