# Clear terminal.
clear
bash settings/banners/logo.sh