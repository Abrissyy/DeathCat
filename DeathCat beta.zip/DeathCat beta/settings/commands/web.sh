# Upload mod (web interface).
python3 settings/commands/web/web.py