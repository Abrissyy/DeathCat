#!/bin/bash

echo -e "\
  _____             _   _      _____      _   
 |  __ \           | | | |    / ____|    | |  
 | |  | | ___  __ _| |_| |__ | |     __ _| |_ 
 | |  | |/ _ \/ _  | __|  _ \| |    / _  | __|
 | |__| |  __/ (_| | |_| | | | |___| (_| | |_ 
 |_____/ \___|\__,_|\__|_| |_|\_____\__,_|\__|
Welcome to \033[31mDeathCat\033[0m\n\
The best pentesting tool and tool firmware

\033[31mremember to use this for educational purposes only !!!\033[0m\n\

(For peoples who looks for nice design. design is not everything i dont need fucking nice view
edit this by yourself if you want)
                                              
"
