# Abrissy mutlitool. its 100% safe and opensource
# if you copying any part of code and you want share it anywhere
# please add credits to my github/telegram
#!/bin/bash

function color_echo() {
    local color_code=$1
    shift
    echo -e "\033[${color_code}m$@\033[0m"
}

function load_settings() {
    local settings_file="settings/settings.json"
    if [[ ! -f $settings_file ]]; then
        color_echo "31" "where is ($settings_file)"
        exit 1
    fi
    username=$(grep -oP '"username": *"\K[^"]+' "$settings_file")
    text_color=$(grep -oP '"text_color": *"\K[^"]+' "$settings_file")
}

function show_logo() {
    local logo_file="settings/banners/logo.sh"
    if [[ ! -f $logo_file ]]; then
        color_echo "31" "where is ($logo_file)"
        exit 1
    fi
    bash -e "$logo_file"
}

function load_prompt() {
    local prompt_file="settings/banners/prompt.ay"
    if [[ ! -f $prompt_file ]]; then
        color_echo "31" "where is ($prompt_file)"
        exit 1
    fi
    prompt_text=$(cat "$prompt_file")
}

function run_command() {
    local command_name=$1
    local command_file="settings/commands/${command_name}.sh"
    if [[ ! -f $command_file ]]; then
        color_echo "31" "Command ($command_name) not found"
        exit 1
    fi
    bash "$command_file"
}

load_settings

show_logo

load_prompt

while true; do
    read -p "$prompt_text" command
    if [[ $command == "exit" ]]; then
        break
    fi
    run_command "$command"
done
